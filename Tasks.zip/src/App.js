import logo from './logo.svg';
import './App.css';
import details from "./db/EmployeeDetails.json";
import Task from './Task';
// import Addele from './Addele';
import Fetching from './Fetching';
import Radio from './Radio';

function App() {
// console.log(details)
  return (
    <div className="App">
      {/* <Fetching/> */}

      {/* <Radio/> */}
     <Task/>
     {/* <Addele/> */}
     {/* <Sample/> */}
    </div>
  );
}

export default App;
